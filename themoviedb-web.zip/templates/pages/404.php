<?php
include_once('./utils/correct-path.php');

include_once('./templates/partials/header.php'); ?>

<div class="erro__center">
    <img src="./assets/img/404.png" alt="">
    <h1>Erro 404</h1>
</div>

<?php include_once('./templates/partials/footer.php'); ?>
