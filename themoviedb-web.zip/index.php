<?php
require_once('./controllers/MainController.php');

define('BASE_PATH', 'http://localhost/'. basename(__DIR__));

MainController();


